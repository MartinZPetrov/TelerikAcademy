﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Problem 5. Print Your Name

//Modify the previous application to print your name.
//Ensure you have named the application well (e.g. “PrintMyName”).
//You should submit a separate project Visual Studio project holding the PrintMyName class as part of your homework.
namespace _5.PrintNamq
{
    class PrintName
    {
        static void Main(string[] args)
        {
            string name = "Martin";
            Console.WriteLine("Hi my name is {0}", name);
        }
    }
}
