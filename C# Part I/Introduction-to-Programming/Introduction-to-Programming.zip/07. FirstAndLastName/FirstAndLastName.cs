﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Problem 7. Print First and Last Name
namespace _7.FirstAndLastName
{
    class FirstAndLastName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Martin");
            Console.WriteLine("Petrov");

        }
    }
}
