# TelerikAcademy
Exercise coding is the main goal.
