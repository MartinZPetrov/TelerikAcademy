﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Problem 14.* Current Date and Time
//Create a console application that prints the current date and time. Find out how in Internet.
namespace _14.CurrentDateTime
{
    class CurrentDateTime
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now);
        }
    }
}
